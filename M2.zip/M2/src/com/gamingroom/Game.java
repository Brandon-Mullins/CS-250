package com.gamingroom;

public class Game extends Entity {

    // Constructor that accepts id and name
    public Game(long id, String name) {
        super(id, name); // Call the constructor of Entity
    }

    // Additional methods specific to Game can go here
}
