package com.gamingroom;

public class ProgramDriver {

    public static void main(String[] args) {

        GameService service = GameService.getInstance(); // This should resolve correctly

        System.out.println("\nAbout to test initializing game data...");

        // Add and print game data
        Game game1 = service.addGame("Game #1");
        System.out.println("Added game: " + game1.getName());

        Game game2 = service.addGame("Game #2");
        System.out.println("Added game: " + game2.getName());

        // Test Singleton behavior
        SingletonTester tester = new SingletonTester();
        tester.testSingleton();
    }
}
