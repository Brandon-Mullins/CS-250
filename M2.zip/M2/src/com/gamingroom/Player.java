package com.gamingroom;

public class Player extends Entity {

    public Player(long id, String name) {
        super(id, name); // Call the constructor of Entity
    }

    // Additional player-specific methods can go here
}
