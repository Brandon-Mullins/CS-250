package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

public class GameService {

    private static GameService instance;
    private List<Game> games = new ArrayList<>(); // Ensure this is initialized
    private long nextGameId = 1; // Unique identifier for games

    private GameService() {}

    public static GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }

    public Game addGame(String name) {
        // Check if the name is already in use
        for (Game game : games) {
            if (game.getName().equalsIgnoreCase(name)) {
                System.out.println("Game with name " + name + " already exists!");
                return null; // Return null if the game name is already taken
            }
        }

        // If not, create a new game and add it to the list
        Game game = new Game(nextGameId++, name); // Use the nextGameId for unique IDs
        games.add(game);
        return game;
    }

    public List<Game> getGames() {
        return games; // Ensure this returns the initialized list
    }

    // Other methods...
}
