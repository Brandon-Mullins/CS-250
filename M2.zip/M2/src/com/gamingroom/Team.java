package com.gamingroom;

public class Team extends Entity {

    public Team(long id, String name) {
        super(id, name); // Call the constructor of Entity
    }

    // Additional team-specific methods can go here
}
