package com.gamingroom;

public class SingletonTester {

    public void testSingleton() {
        GameService service = GameService.getInstance(); // Access Singleton

        // Output all games to verify singleton behavior
        for (Game game : service.getGames()) {
            if (game != null) { // Check if the game is not null
                System.out.println("Game: " + game.getName());
            }
        }
    }
}

